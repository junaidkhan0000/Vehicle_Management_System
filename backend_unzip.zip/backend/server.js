const express = require("express");
const mysql = require('mysql2');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "junaid",
    database: "vms"
});

db.connect((err) => {
    if (err) {
        console.error('Error connecting to database:', err);
        return;
    }
    console.log('Connected to database');
});

const emailRegex = /\S+@\S+\.\S+/;

const handleSignup = (req, res) => {
    const { name, email, password } = req.body;

    console.log("Received signup request:", { name, email, password });

    if (!name || !email || !password || !emailRegex.test(email)) {
        return res.status(400).json({ error: 'Name, email, and password are required fields. Make sure the email format is valid.' });
    }

    const sql = "INSERT INTO signup (name, email, password) VALUES (?, ?, ?)";
    const values = [name, email, password];

    console.log('Attempting to insert data:', name, email);

    db.query(sql, values, (err, result) => {
        if (err) {
            console.error('Error inserting data:', err);
            return res.status(500).json({ error: 'An error occurred while processing your request.' });
        }
        console.log('Data inserted successfully:', result);
        res.status(200).json({ success: true });
    });
};

const handleSignin = (req, res) => {
    const { email, password } = req.body;

    console.log("Received signin request:", { email, password });

    const sql = "SELECT * FROM signup WHERE email = ? AND password = ?";
    const values = [email, password];

    db.query(sql, values, (err, result) => {
        if (err) {
            console.error('Error querying data:', err);
            return res.status(500).json({ error: 'An error occurred while processing your request.' });
        }
        
        if (result.length === 0) {
            return res.status(401).json({ error: 'Incorrect email or password.' });
        }

        res.status(200).json({ success: true, message: 'Signin successfully.' });
    });
};

app.post('/signup', handleSignup);
app.post('/signin', handleSignin);


// Route to handle form submission for comments
app.post('/api/comments', (req, res) => {
    const { Full_Name, E_mail, Comment } = req.body;
    if (!Full_Name || !E_mail || !Comment) {
      return res.status(400).json({ error: 'All fields are required' });
    }
  
    const sql = "INSERT INTO comment (Full_Name, E_mail, Comment) VALUES (?, ?, ?)";
    console.log("SQL Query:", sql); // Log SQL query for debugging
    db.query(sql, [Full_Name, E_mail, Comment], (err, result) => {
      if (err) {
        console.error('Error saving comment:', err);
        return res.status(500).json({ error: 'Failed to save comment' });
      }
  
      if (result.affectedRows === 1) {
        console.log('Comment saved successfully');
        return res.status(201).json({ message: 'Comment posted successfully!' });
      } else {
        console.error('Error inserting comment:', result);
        return res.status(500).json({ error: 'Failed to post comment. Please try again.' });
      }
    });
  });
  
  // Route to handle form submission for messages
  app.post('/api/messages', (req, res) => {
    const { Name, Email, Message } = req.body;
    if (!Name || !Email || !Message) {
      return res.status(400).json({ error: 'All fields are required' });
    }
  
    const sql = "INSERT INTO message (Name, Email, Message) VALUES (?, ?, ?)";
    console.log("SQL Query:", sql); // Log SQL query for debugging
    db.query(sql, [Name, Email, Message], (err, result) => {
      if (err) {
        console.error('Error saving message:', err);
        return res.status(500).json({ error: 'Failed to save message' });
      }
  
      if (result.affectedRows === 1) {
        console.log('Message saved successfully');
        return res.status(201).json({ message: 'Message posted successfully!' });
      } else {
        console.error('Error inserting message:', result);
        return res.status(500).json({ error: 'Failed to post message. Please try again.' });
      }
    });
  });

  const processPayment = (amount, upiID) => {
    const sql = 'INSERT INTO payment (amount, upiID) VALUES (?, ?)';
    db.query(sql, [amount, upiID], (err, result) => {
      if (err) {
        throw err;
      }
      console.log(`Payment of ${amount} to ${upiID} inserted successfully!`);
    });
  
    return { status: 'success', message: `Payment of ${amount} to ${upiID} processed successfully!` };
  };
  
  app.post('/process-payment', (req, res) => {
    const { amount, upiID } = req.body;
  
    if (!amount || !upiID) {
      return res.status(400).json({ status: 'error', message: 'Amount and UPI ID are required' });
    }
  
    const isValidUPI = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+$/.test(upiID);
    if (!isValidUPI) {
      return res.status(400).json({ status: 'error', message: 'Invalid UPI ID format' });
    }
  
    const result = processPayment(amount, upiID);
    res.json(result);
  });
  

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
});
